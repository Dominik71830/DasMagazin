package GUIe;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;

public class DodajFormularzMagazynOkno extends JDialog {
	private JTable tableFormularzeMagazyn;
	private JTextField textFieldIle;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DodajFormularzMagazynOkno dialog = new DodajFormularzMagazynOkno();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public DodajFormularzMagazynOkno() {
		setBounds(100, 100, 750, 516);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 463, 393);
		getContentPane().add(scrollPane);
		
		tableFormularzeMagazyn = new JTable();
		scrollPane.setViewportView(tableFormularzeMagazyn);
		
		JComboBox comboBoxProdukty = new JComboBox();
		comboBoxProdukty.setBounds(484, 55, 169, 20);
		getContentPane().add(comboBoxProdukty);
		
		textFieldIle = new JTextField();
		textFieldIle.setBounds(663, 55, 47, 20);
		getContentPane().add(textFieldIle);
		textFieldIle.setColumns(10);
		
		JComboBox comboBoxMiejsceDocelowe = new JComboBox();
		comboBoxMiejsceDocelowe.setBounds(483, 153, 169, 20);
		getContentPane().add(comboBoxMiejsceDocelowe);
		
		JButton btnNewButton = new JButton("Wstaw");
		btnNewButton.setBounds(637, 86, 73, 23);
		getContentPane().add(btnNewButton);
		
		JLabel lblWstawProdukty = new JLabel("Wstaw produkty");
		lblWstawProdukty.setBounds(483, 30, 89, 14);
		getContentPane().add(lblWstawProdukty);
		
		JLabel lblWybierzMiejsce = new JLabel("Wybierz miejsce docelowe");
		lblWybierzMiejsce.setBounds(483, 131, 147, 14);
		getContentPane().add(lblWybierzMiejsce);
		
		JLabel lblWybierzSamochdDostawczy = new JLabel("Wybierz samoch\u00F3d dostawczy");
		lblWybierzSamochdDostawczy.setBounds(483, 196, 170, 14);
		getContentPane().add(lblWybierzSamochdDostawczy);
		
		JComboBox comboBoxAuta = new JComboBox();
		comboBoxAuta.setBounds(483, 221, 170, 20);
		getContentPane().add(comboBoxAuta);
		
		JButton btnZrobione = new JButton("Zrobione");
		btnZrobione.setBounds(444, 444, 89, 23);
		getContentPane().add(btnZrobione);
		
		JButton btnPowrt = new JButton("Powr\u00F3t");
		btnPowrt.setBounds(637, 444, 89, 23);
		getContentPane().add(btnPowrt);
		
		JButton btnUsu = new JButton("Usu\u0144");
		btnUsu.setBounds(541, 444, 89, 23);
		getContentPane().add(btnUsu);

	}
}
