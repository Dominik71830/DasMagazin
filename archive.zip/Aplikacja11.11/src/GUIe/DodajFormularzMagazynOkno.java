package GUIe;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

public class DodajFormularzMagazynOkno extends JDialog {
	private JTable tableFormularzeMagazyn;
	private JTextField textFieldIle;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DodajFormularzMagazynOkno dialog = new DodajFormularzMagazynOkno();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public DodajFormularzMagazynOkno() {
		setBounds(100, 100, 687, 480);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPaneFormularzeMagazyn = new JScrollPane();
		scrollPaneFormularzeMagazyn.setBounds(26, 31, 438, 332);
		getContentPane().add(scrollPaneFormularzeMagazyn);
		
		tableFormularzeMagazyn = new JTable();
		scrollPaneFormularzeMagazyn.setViewportView(tableFormularzeMagazyn);
		
		JComboBox comboBoxprodukty = new JComboBox();
		comboBoxprodukty.setBounds(492, 43, 119, 20);
		getContentPane().add(comboBoxprodukty);
		
		textFieldIle = new JTextField();
		textFieldIle.setBounds(621, 43, 40, 20);
		getContentPane().add(textFieldIle);
		textFieldIle.setColumns(10);
		
		JComboBox comboBoxMiejsceDocelowe = new JComboBox();
		comboBoxMiejsceDocelowe.setBounds(492, 89, 119, 20);
		getContentPane().add(comboBoxMiejsceDocelowe);
		
		JComboBox comboBoxAuta = new JComboBox();
		comboBoxAuta.setBounds(492, 134, 119, 20);
		getContentPane().add(comboBoxAuta);
		
		JButton btnDodaj = new JButton("Dodaj");
		btnDodaj.setBounds(509, 202, 89, 23);
		getContentPane().add(btnDodaj);
		
		JButton btnPowrt = new JButton("Powr\u00F3t");
		btnPowrt.setBounds(572, 408, 89, 23);
		getContentPane().add(btnPowrt);
		
		JButton btnUsu = new JButton("Usu\u0144");
		btnUsu.setBounds(509, 236, 89, 23);
		getContentPane().add(btnUsu);

	}
}
