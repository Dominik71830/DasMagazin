package GUIe;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;

public class LogiOkienko extends JDialog {
	private JTable tableLogi;

	
	public LogiOkienko() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblOstatnieZmiany = new JLabel("Ostatnie zmiany");
		lblOstatnieZmiany.setBounds(10, 11, 89, 14);
		getContentPane().add(lblOstatnieZmiany);
		
		JScrollPane scrollPaneLogi = new JScrollPane();
		scrollPaneLogi.setBounds(20, 36, 404, 188);
		getContentPane().add(scrollPaneLogi);
		
		tableLogi = new JTable();
		scrollPaneLogi.setViewportView(tableLogi);
		
		JButton btnPowrt = new JButton("Powr\u00F3t");
		btnPowrt.setBounds(335, 228, 89, 23);
		getContentPane().add(btnPowrt);

	}
}
