package GUIe;

import java.awt.EventQueue;
import java.awt.Image;
import java.io.IOException;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.omg.PortableServer.ServantRetentionPolicyValue;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Button;
import java.awt.Canvas;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GlowneOkno {

	private JFrame frmTytuwiczebny;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GlowneOkno window = new GlowneOkno();
					window.frmTytuwiczebny.setVisible(true);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null,"B��d przy Otwieraniu okna g��wnego " + e);
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GlowneOkno() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmTytuwiczebny = new JFrame();
		frmTytuwiczebny.setTitle("tytu\u0142 \u0107wiczebny");
		frmTytuwiczebny.setBounds(0, 0, 1065, 600);
		frmTytuwiczebny.setLocationRelativeTo(null);
		frmTytuwiczebny.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmTytuwiczebny.getContentPane().setLayout(null);
		
		JButton Przycisk1 = new JButton("Dzia\u0142 magazynowy");
		Przycisk1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MagazynOkno magazynokno = new MagazynOkno();
				magazynokno.setVisible(true);
			}
		});
		Przycisk1.setBounds(31, 39, 291, 378);
		frmTytuwiczebny.getContentPane().add(Przycisk1);
		
		JButton btnNewButton_1 = new JButton("Dzia\u0142 sprzeda\u017Cy detalicznej");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SprzedazDetalicznaOkno okno = new SprzedazDetalicznaOkno();
				okno.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(383, 39, 291, 378);
		frmTytuwiczebny.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Dzia\u0142 sprzeda\u017Cy hurtowej");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SprzedazMagazynowaOkno okno;
				try {
					okno = new SprzedazMagazynowaOkno();
					okno.setVisible(true);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null,"B��d przy tworzeniu nowego okna SprzedazMagazynowa " + e1);
				}
				
			}
		});
		btnNewButton_2.setBounds(728, 39, 291, 378);
		frmTytuwiczebny.getContentPane().add(btnNewButton_2);
		
		JButton btnWyloguj = new JButton("Wyjd\u017A");
		btnWyloguj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			      System.exit(0); 
			}
		});
		btnWyloguj.setBounds(799, 446, 220, 91);
		frmTytuwiczebny.getContentPane().add(btnWyloguj);
	}
}
