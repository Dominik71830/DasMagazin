package GUIe;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;

public class SprzedazDetalicznaOkno extends JDialog {
	private JTable tableformularz;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SprzedazDetalicznaOkno dialog = new SprzedazDetalicznaOkno();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public SprzedazDetalicznaOkno() {
		setTitle("Sprzeda\u017C detaliczna");
		setBounds(100, 100, 603, 411);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPaneFormularz = new JScrollPane();
		scrollPaneFormularz.setBounds(201, 21, 376, 301);
		getContentPane().add(scrollPaneFormularz);
		
		tableformularz = new JTable();
		scrollPaneFormularz.setViewportView(tableformularz);
		
		JButton btnWywietlFormularz = new JButton("Wy\u015Bwietl formularz");
		btnWywietlFormularz.setBounds(33, 21, 147, 23);
		getContentPane().add(btnWywietlFormularz);
		
		JButton btnDodajFormularz = new JButton("Dodaj formularz");
		btnDodajFormularz.setBounds(33, 55, 147, 23);
		getContentPane().add(btnDodajFormularz);
		
		JButton btnUsunFormularz = new JButton("Usu\u0144 formularz");
		btnUsunFormularz.setBounds(33, 89, 147, 23);
		getContentPane().add(btnUsunFormularz);
		
		JButton btnPowrt = new JButton("Powr\u00F3t");
		btnPowrt.setBounds(488, 339, 89, 23);
		getContentPane().add(btnPowrt);

	}
}
