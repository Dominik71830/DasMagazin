package GUIe;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTable;

public class DodajFormularzeDetalOkno extends JDialog {
	private JTable tableProdukty;
	private JTable tableProduktyDodane;
	public DodajFormularzeDetalOkno() {
		setTitle("Dodaj formularz");
		getContentPane().setLayout(null);
		
		JScrollPane scrollPaneProdukty = new JScrollPane();
		scrollPaneProdukty.setBounds(472, 26, 283, 292);
		getContentPane().add(scrollPaneProdukty);
		
		tableProdukty = new JTable();
		scrollPaneProdukty.setViewportView(tableProdukty);
		
		JScrollPane scrollPaneProduktyDodane = new JScrollPane();
		scrollPaneProduktyDodane.setBounds(179, 26, 283, 292);
		getContentPane().add(scrollPaneProduktyDodane);
		
		tableProduktyDodane = new JTable();
		scrollPaneProduktyDodane.setViewportView(tableProduktyDodane);
		
		JButton btnPowrt = new JButton("Powr\u00F3t");
		btnPowrt.setBounds(666, 329, 89, 23);
		getContentPane().add(btnPowrt);
		
		JLabel lblDodajProduktZ = new JLabel("Dodaj produkt z listy");
		lblDodajProduktZ.setBounds(23, 26, 135, 14);
		getContentPane().add(lblDodajProduktZ);
	}
}
