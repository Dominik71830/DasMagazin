package GUIe;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class ZatwierdzenieOUsuwaniuOkienko extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ZatwierdzenieOUsuwaniuOkienko dialog = new ZatwierdzenieOUsuwaniuOkienko();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public ZatwierdzenieOUsuwaniuOkienko() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel JLabeltekst = new JLabel("Czy aby napewno chcesz usun\u0105\u0107 ten obiekt?");
		JLabeltekst.setHorizontalAlignment(SwingConstants.CENTER);
		JLabeltekst.setFont(new Font("Tahoma", Font.PLAIN, 18));
		JLabeltekst.setBounds(21, 30, 384, 75);
		getContentPane().add(JLabeltekst);
		
		JButton btnTak = new JButton("Tak");
		btnTak.setBounds(89, 169, 89, 23);
		getContentPane().add(btnTak);
		
		JButton btnNie = new JButton("Nie");
		btnNie.setBounds(255, 169, 89, 23);
		getContentPane().add(btnNie);

	}
}
