package pakiet;

public class Samochod {
	private int id;
	private String model;
	private String nr_rejestracyjny;
	private Double ladownosc;
	private boolean czy_jest_na_stanie;
	
	public Samochod(int id, String model, String nr_rejestracyjny, Double ladownosc, boolean czy_jest_na_stanie) {
		super();
		this.id = id;
		this.model = model;
		this.nr_rejestracyjny = nr_rejestracyjny;
		this.ladownosc = ladownosc;
		this.czy_jest_na_stanie = czy_jest_na_stanie;
	}

	public Samochod(String model, String nr_rejestracyjny, Double ladownosc, boolean czy_jest_na_stanie) {
		super();
		this.model = model;
		this.nr_rejestracyjny = nr_rejestracyjny;
		this.ladownosc = ladownosc;
		this.czy_jest_na_stanie = czy_jest_na_stanie;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getNr_rejestracyjny() {
		return nr_rejestracyjny;
	}

	public void setNr_rejestracyjny(String nr_rejestracyjny) {
		this.nr_rejestracyjny = nr_rejestracyjny;
	}

	public Double getLadownosc() {
		return ladownosc;
	}

	public void setLadownosc(Double ladownosc) {
		this.ladownosc = ladownosc;
	}

	public boolean isCzy_jest_na_stanie() {
		return czy_jest_na_stanie;
	}

	public void setCzy_jest_na_stanie(boolean czy_jest_na_stanie) {
		this.czy_jest_na_stanie = czy_jest_na_stanie;
	}

	@Override
	public String toString() {
		return "Samochod [id=" + id + ", model=" + model + ", nr_rejestracyjny=" + nr_rejestracyjny + ", ladownosc="
				+ ladownosc + ", czy_jest_na_stanie=" + czy_jest_na_stanie + "]";
	}
	
	
}
